SELECT * FROM "TelegramSettings";
