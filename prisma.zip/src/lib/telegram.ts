import TelegramBot from "node-telegram-bot-api";
import { getPrisma } from "./prisma";

let botInstance: TelegramBot | null = null;

export async function getTelegramBot() {
    if (botInstance) return botInstance;

    const prisma = getPrisma();
    const settings = await prisma.telegramSettings.findFirst();
    if (!settings || !settings.enabled || !settings.bot_token_encrypted) {
        return null;
    }

    // Basic implementation without real encryption for simplicity,
    // but in prod you would decrypt settings.bot_token_encrypted here.
    const token = settings.bot_token_encrypted;
    botInstance = new TelegramBot(token, { polling: false });
    return botInstance;
}

export async function sendTelegramMessage(chatId: string, text: string) {
    try {
        const bot = await getTelegramBot();
        if (!bot) {
            console.warn("Telegram bot not configured or disabled.");
            return false;
        }
        await bot.sendMessage(chatId, text, { parse_mode: "HTML" });
        return true;
    } catch (err) {
        console.error("Failed to send Telegram message", err);
        return false;
    }
}
