import { HttpsProxyAgent } from "https-proxy-agent";
import axios from "axios";

export const DEFAULT_TIMEOUT = 10000; // 10s
export const BLOCK_KEYWORDS = ["internet positif", "trustpositif", "nawala", "mercusuar"];

export type CheckOutput = {
    status: "AMAN" | "BLOCKIR" | "REDIRECT" | "TIMEOUT";
    http_status: number | null;
    final_url: string | null;
    latency_ms: number;
    error_code: string | null;
};

export async function checkDomain(domain: string, proxyUrl?: string, timeoutMs: number = DEFAULT_TIMEOUT): Promise<CheckOutput> {
    const url = `http://${domain}`;
    const start = Date.now();

    try {
        const options: any = {
            method: 'GET',
            timeout: timeoutMs,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            },
            maxRedirects: 5,
            validateStatus: () => true // Resolve all statuses so we can check 451 etc.
        };

        if (proxyUrl) {
            options.httpsAgent = new HttpsProxyAgent(proxyUrl);
            options.proxy = false; // Disable axios default proxy handling
        }

        const response = await axios.get(url, options);

        const latency_ms = Date.now() - start;
        const final_url = response.request?.res?.responseUrl || url;
        const http_status = response.status;

        // Check Status 451
        if (http_status === 451) {
            return { status: "BLOCKIR", http_status, final_url, latency_ms, error_code: "451_UNAVAILABLE" };
        }

        // Check Redirects to known block pages
        const isRedirected = final_url !== url && final_url !== `${url}/`;
        if (isRedirected) {
            const isBlockRedirect = BLOCK_KEYWORDS.some(kw => final_url.toLowerCase().includes(kw));
            if (isBlockRedirect) {
                return { status: "BLOCKIR", http_status, final_url, latency_ms, error_code: "REDIRECT_BLOCK" };
            }
            return { status: "REDIRECT", http_status, final_url, latency_ms, error_code: null };
        }

        // Check Title / Content
        const text = typeof response.data === 'string' ? response.data : JSON.stringify(response.data);
        const titleMatch = text.match(/<title>(.*?)<\/title>/i);
        const title = titleMatch ? titleMatch[1].toLowerCase() : "";

        const isBlockContent = BLOCK_KEYWORDS.some(kw => title.includes(kw) || text.toLowerCase().includes(kw));
        if (isBlockContent) {
            return { status: "BLOCKIR", http_status, final_url, latency_ms, error_code: "CONTENT_BLOCK" };
        }

        return { status: "AMAN", http_status, final_url, latency_ms, error_code: null };

    } catch (err: any) {
        const latency_ms = Date.now() - start;

        if (err.code === 'ECONNABORTED' || err.message?.includes('timeout')) {
            return { status: "TIMEOUT", http_status: null, final_url: null, latency_ms, error_code: "TIMEOUT" };
        }

        return { status: "TIMEOUT", http_status: null, final_url: null, latency_ms, error_code: err.code || "CONN_ERROR" };
    }
}
