"use client";

import { useState, useEffect } from "react";
import { Plus, Search, CheckCircle, XCircle, AlertTriangle, RefreshCw, Trash2, Globe } from "lucide-react";

type Domain = {
    id: string;
    domain: string;
    group_name: string | null;
    is_active: boolean;
    createdAt: string;
    checks: any[];
};

export default function DomainsPage() {
    const [domains, setDomains] = useState<Domain[]>([]);
    const [total, setTotal] = useState(0);
    const [page, setPage] = useState(1);
    const [search, setSearch] = useState("");
    const [loading, setLoading] = useState(true);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [addInput, setAddInput] = useState("");

    const fetchDomains = async () => {
        setLoading(true);
        try {
            const res = await fetch(`/api/admin/domains?search=${encodeURIComponent(search)}&page=${page}&pageSize=50`);
            const data = await res.json();
            if (data.domains) {
                setDomains(data.domains);
                setTotal(data.total);
            }
        } catch (error) {
            console.error("Failed to load domains", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        const timeout = setTimeout(() => fetchDomains(), 500);
        return () => clearTimeout(timeout);
    }, [search, page]);

    const handleAddDomains = async (e: React.FormEvent) => {
        e.preventDefault();
        const lines = addInput.split('\n').map(l => l.trim()).filter(l => l.length > 0);
        if (lines.length === 0) return;

        const payload = lines.map(line => {
            return { domain: line, group_name: "Default", is_active: true };
        });

        const res = await fetch('/api/admin/domains', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ domains: payload })
        });

        if (res.ok) {
            setAddInput("");
            setIsAddModalOpen(false);
            setPage(1);
            fetchDomains();
        } else {
            alert("Failed to add domains");
        }
    };

    const handleDeleteDomain = async (id: string, domainName: string) => {
        if (!confirm(`Are you sure you want to delete ${domainName}?`)) return;

        try {
            const res = await fetch(`/api/admin/domains?id=${id}`, {
                method: "DELETE"
            });
            if (res.ok) {
                fetchDomains();
            } else {
                alert("Failed to delete domain");
            }
        } catch (error) {
            console.error(error);
        }
    };

    const getStatusBadge = (checks: any[]) => {
        if (!checks || checks.length === 0) {
            return <span className="inline-flex items-center text-xs font-semibold text-neutral-400 bg-neutral-800 px-2 py-1 rounded border border-neutral-700">WAITING</span>;
        }
        const status = checks[0].status;
        if (status === 'AMAN') return <span className="inline-flex items-center text-xs font-semibold text-emerald-400 bg-emerald-400/10 px-2.5 py-1 rounded border border-emerald-400/20"><CheckCircle className="w-3 h-3 mr-1.5" /> AMAN</span>;
        if (status === 'BLOCKIR' || status === 'REDIRECT' || status === 'TIMEOUT') return <span className="inline-flex items-center text-xs font-semibold text-red-400 bg-red-400/10 px-2.5 py-1 rounded border border-red-400/20"><AlertTriangle className="w-3 h-3 mr-1.5" /> {status}</span>;
        return <span className="inline-flex items-center text-xs font-semibold text-yellow-400 bg-yellow-400/10 px-2.5 py-1 rounded border border-yellow-400/20">{status}</span>;
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-white tracking-tight">Domain Management</h2>
                    <p className="text-neutral-400 text-sm mt-1">Manage and monitor your checked domains ({total} total)</p>
                </div>
                <button
                    onClick={() => setIsAddModalOpen(true)}
                    className="bg-emerald-500 hover:bg-emerald-600 text-neutral-950 font-bold py-2 px-6 rounded-xl flex items-center transition-all shadow-[0_0_20px_rgba(16,185,129,0.2)] hover:shadow-[0_0_25px_rgba(16,185,129,0.4)]"
                >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Domains
                </button>
            </div>

            <div className="glass-card p-4">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500 w-5 h-5" />
                    <input
                        type="text"
                        placeholder="Search domains..."
                        className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-3 pl-11 pr-4 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all placeholder:text-neutral-600"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
            </div>

            <div className="glass-card overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm text-neutral-400">
                        <thead className="bg-neutral-900/50 border-b border-neutral-800 text-xs uppercase font-semibold text-neutral-500">
                            <tr>
                                <th className="px-6 py-4">Domain</th>
                                <th className="px-6 py-4">Status</th>
                                <th className="px-6 py-4">Group</th>
                                <th className="px-6 py-4 text-right">Added</th>
                                <th className="px-6 py-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-neutral-800/50">
                            {loading && domains.length === 0 ? (
                                <tr>
                                    <td colSpan={4} className="px-6 py-8 text-center text-neutral-500">Loading domains...</td>
                                </tr>
                            ) : domains.length === 0 ? (
                                <tr>
                                    <td colSpan={4} className="px-6 py-8 text-center text-neutral-500">No domains found</td>
                                </tr>
                            ) : (
                                domains.map(d => (
                                    <tr key={d.id} className="hover:bg-neutral-900/30 transition-colors group">
                                        <td className="px-6 py-4">
                                            <div className="flex items-center">
                                                <Globe className="w-4 h-4 mr-3 text-neutral-600 group-hover:text-emerald-500 transition-colors" />
                                                <span className="font-medium text-white">{d.domain}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">{getStatusBadge(d.checks)}</td>
                                        <td className="px-6 py-4">{d.group_name || "-"}</td>
                                        <td className="px-6 py-4 text-right">{new Date(d.createdAt).toLocaleDateString()}</td>
                                        <td className="px-6 py-4 text-right">
                                            <button
                                                onClick={() => handleDeleteDomain(d.id, d.domain)}
                                                className="text-neutral-500 hover:text-red-400 transition-colors p-2 hover:bg-neutral-800 rounded-lg"
                                                title="Delete Domain"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>

                {/* Pagination */}
                <div className="px-6 py-4 border-t border-neutral-800 flex items-center justify-between">
                    <div className="text-sm text-neutral-500">
                        Showing {domains.length} of {total} domains
                    </div>
                    <div className="flex gap-2">
                        <button
                            disabled={page === 1}
                            onClick={() => setPage(p => Math.max(1, p - 1))}
                            className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-50 disabled:cursor-not-allowed border border-neutral-800 rounded-lg text-white font-medium transition-colors"
                        >
                            Previous
                        </button>
                        <button
                            disabled={domains.length < 50}
                            onClick={() => setPage(p => p + 1)}
                            className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-50 disabled:cursor-not-allowed border border-neutral-800 rounded-lg text-white font-medium transition-colors"
                        >
                            Next
                        </button>
                    </div>
                </div>
            </div>

            {/* Modal for adding domains */}
            {isAddModalOpen && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                    <div className="glass-card w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-200">
                        <div className="p-6 border-b border-neutral-800 flex justify-between items-center bg-neutral-900/50">
                            <h3 className="text-lg font-bold text-white">Add Domains</h3>
                            <button onClick={() => setIsAddModalOpen(false)} className="text-neutral-500 hover:text-white transition-colors">
                                <XCircle className="w-6 h-6" />
                            </button>
                        </div>
                        <form onSubmit={handleAddDomains} className="p-6 space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-neutral-400 mb-2">
                                    Domains (one per line)
                                </label>
                                <textarea
                                    value={addInput}
                                    onChange={(e) => setAddInput(e.target.value)}
                                    placeholder="example1.com&#10;example2.com"
                                    rows={6}
                                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-4 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-mono text-sm"
                                    required
                                />
                            </div>
                            <p className="text-xs text-neutral-500">
                                Enter up to 50 domains at once to import them quickly. Group name will default to "Default".
                            </p>
                            <div className="flex justify-end pt-4">
                                <button
                                    type="button"
                                    onClick={() => setIsAddModalOpen(false)}
                                    className="px-6 py-2 rounded-xl text-neutral-400 hover:text-white font-medium transition-colors mr-3"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={!addInput.trim()}
                                    className="bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-neutral-950 font-bold py-2 px-6 rounded-xl transition-all shadow-[0_0_20px_rgba(16,185,129,0.2)]"
                                >
                                    Import Domains
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}
