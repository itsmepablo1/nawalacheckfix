"use client";

import { useState, useEffect } from "react";
import { Network, ServerCog, Plug, Save, ActivitySquare, CheckCircle, XCircle } from "lucide-react";

export default function ProvidersPage() {
    const [providers, setProviders] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [savingConfig, setSavingConfig] = useState<string | null>(null);
    const [testingConfig, setTestingConfig] = useState<string | null>(null);
    const [testResults, setTestResults] = useState<Record<string, any>>({});

    const fetchProviders = async () => {
        setLoading(true);
        try {
            const res = await fetch("/api/admin/providers");
            const data = await res.json();
            if (data.providers) setProviders(data.providers);
        } catch (error) {
            console.error(error);
        }
        setLoading(false);
    };

    useEffect(() => {
        fetchProviders();
    }, []);

    const handleSaveProxy = async (key: string, proxy_url: string) => {
        setSavingConfig(key);
        try {
            const res = await fetch("/api/admin/providers", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ key, proxy_url })
            });
            if (!res.ok) {
                const data = await res.json();
                alert(data.error || "Failed to update proxy.");
            }
        } catch (error) {
            alert("Network error");
        }
        setSavingConfig(null);
        fetchProviders();
    };

    const handleInputChange = (key: string, value: string) => {
        setProviders(prev => prev.map(p => p.key === key ? { ...p, proxyUrlInput: value } : p));
        // Clear previous test results when input changes
        if (testResults[key]) {
            setTestResults(prev => {
                const newResults = { ...prev };
                delete newResults[key];
                return newResults;
            });
        }
    };

    const handleTestProxy = async (key: string, proxy_url: string) => {
        if (!proxy_url) {
            alert("Proxy URL cannot be empty for testing");
            return;
        }

        setTestingConfig(key);
        setTestResults(prev => ({ ...prev, [key]: { loading: true } }));

        try {
            const res = await fetch("/api/admin/providers/test", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ proxy_url })
            });
            const data = await res.json();

            if (res.ok && data.success) {
                setTestResults(prev => ({
                    ...prev,
                    [key]: { success: true, latency: data.latency, info: data.data }
                }));
            } else {
                setTestResults(prev => ({
                    ...prev,
                    [key]: { success: false, error: data.error || "Unknown Error" }
                }));
            }
        } catch (error: any) {
            setTestResults(prev => ({
                ...prev,
                [key]: { success: false, error: "Network/Timeout Error" }
            }));
        }
        setTestingConfig(null);
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div>
                <h2 className="text-2xl font-bold text-white tracking-tight">Providers & Proxies</h2>
                <p className="text-neutral-400 text-sm mt-1">Configure proxy settings for accurate ISP block checking</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {loading ? (
                    <div className="col-span-full text-center py-10 text-neutral-500">Loading configurations...</div>
                ) : (
                    providers.map((p) => {
                        // Initialize local input state for the proxy url
                        if (p.proxyUrlInput === undefined) p.proxyUrlInput = p.proxy_url || "";

                        const currentTest = testResults[p.key];

                        return (
                            <div key={p.key} className="glass-card p-6 flex flex-col hover:border-emerald-500/30 transition-colors">
                                <div className="flex items-center justify-between mb-4">
                                    <div className="flex items-center">
                                        <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center mr-3 border border-neutral-700">
                                            <Network className="w-5 h-5 text-neutral-400" />
                                        </div>
                                        <div>
                                            <h3 className="text-lg font-bold text-emerald-400">{p.name || p.key}</h3>
                                            <div className="text-xs text-neutral-500 font-mono tracking-widest">{p.key}</div>
                                        </div>
                                    </div>
                                    <div className={`px-2.5 py-1 rounded text-xs font-bold ${p.proxy_url ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'}`}>
                                        {p.proxy_url ? 'PROXY SET' : 'DEFAULT IP'}
                                    </div>
                                </div>

                                <div className="mt-auto space-y-3">
                                    <div className="space-y-1">
                                        <label className="text-xs font-semibold text-neutral-400 uppercase tracking-wider flex items-center">
                                            <ServerCog className="w-3 h-3 mr-1" /> HTTP/SOCKS Proxy URL
                                        </label>
                                        <input
                                            type="text"
                                            value={p.proxyUrlInput}
                                            onChange={(e) => handleInputChange(p.key, e.target.value)}
                                            placeholder="http://user:pass@127.0.0.1:8080"
                                            className="w-full bg-neutral-950 border border-neutral-800 text-neutral-300 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 font-mono"
                                        />
                                    </div>
                                    <div className="flex flex-col sm:flex-row gap-2 mt-4">
                                        <button
                                            onClick={() => handleTestProxy(p.key, p.proxyUrlInput)}
                                            disabled={testingConfig === p.key || savingConfig === p.key}
                                            className="flex-1 bg-amber-500/10 border border-amber-500/30 hover:bg-amber-500 hover:text-neutral-950 text-amber-500 font-semibold py-2 rounded-xl text-sm transition-all flex justify-center items-center disabled:opacity-50"
                                        >
                                            <ActivitySquare className={`w-4 h-4 mr-2 ${testingConfig === p.key && 'animate-spin'}`} />
                                            {testingConfig === p.key ? 'Testing...' : 'Test Connection'}
                                        </button>
                                        <button
                                            onClick={() => handleSaveProxy(p.key, p.proxyUrlInput)}
                                            disabled={savingConfig === p.key || testingConfig === p.key}
                                            className="flex-1 bg-neutral-800 hover:bg-emerald-500 hover:text-neutral-950 text-neutral-300 font-semibold py-2 rounded-xl text-sm transition-all flex justify-center items-center disabled:opacity-50"
                                        >
                                            <Save className="w-4 h-4 mr-2" />
                                            {savingConfig === p.key ? 'Saving...' : 'Save Config'}
                                        </button>
                                    </div>

                                    {/* Test Result Display */}
                                    {currentTest && !currentTest.loading && (
                                        <div className={`mt-3 p-3 rounded-lg text-xs font-mono border ${currentTest.success ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-rose-500/10 border-rose-500/20 text-rose-400'}`}>
                                            {currentTest.success ? (
                                                <div>
                                                    <div className="flex items-center font-bold mb-1">
                                                        <CheckCircle className="w-3 h-3 mr-1" /> Connection Successful ({currentTest.latency}ms)
                                                    </div>
                                                    <div>IP: <span className="text-emerald-300">{currentTest.info.query}</span></div>
                                                    <div>Location: {currentTest.info.city}, {currentTest.info.country}</div>
                                                    <div>ISP: {currentTest.info.isp}</div>
                                                </div>
                                            ) : (
                                                <div className="flex items-start">
                                                    <XCircle className="w-4 h-4 mr-1.5 mt-0.5 shrink-0" />
                                                    <span>API Error: {currentTest.error}</span>
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>
                            </div>
                        );
                    })
                )}
            </div>
        </div>
    );
}
