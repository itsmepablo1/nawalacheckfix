"use client";

import { useEffect, useState } from "react";
import { Activity, Globe, AlertTriangle, CheckCircle, RefreshCw } from "lucide-react";

type StatCardProps = { title: string; value: string; icon: any; color: string; trend?: string };

function StatCard({ title, value, icon: Icon, color, trend }: StatCardProps) {
    return (
        <div className="glass-card p-6 flex items-start justify-between group">
            <div>
                <h3 className="text-neutral-400 text-sm font-medium mb-2">{title}</h3>
                <div className="text-3xl font-bold tracking-tight text-white mb-1">{value}</div>
                {trend && <div className="text-xs text-neutral-500">{trend}</div>}
            </div>
            <div className={`p-3 rounded-xl bg-${color}-500/10 text-${color}-400 group-hover:scale-110 transition-transform duration-300`}>
                <Icon className="w-6 h-6" />
            </div>
        </div>
    );
}

export default function DashboardPage() {
    const [stats, setStats] = useState({ totalDomains: 0, checkedToday: 0, currentlyBlocked: 0 });
    const [domainsData, setDomainsData] = useState<any[]>([]);
    const [providers, setProviders] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [checkStatus, setCheckStatus] = useState("");

    useEffect(() => {
        const fetchDashboardData = async () => {
            try {
                const res = await fetch("/api/admin/dashboard");
                const data = await res.json();
                if (data && data.stats) {
                    setStats(data.stats);
                    setDomainsData(data.domains || []);
                    setProviders(data.providers || []);
                }
            } catch (error) {
                console.error("Dashboard fetch error:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchDashboardData();
        const interval = setInterval(fetchDashboardData, 10000);
        return () => clearInterval(interval);
    }, []);

    const triggerChecks = async () => {
        setLoading(true);
        setCheckStatus("Initiating background checks...");

        try {
            await fetch("/api/admin/checks/trigger", { method: "POST" });
            setCheckStatus("Checks are now running in the background. Check 'Domains' tab later.");
            setTimeout(() => setCheckStatus(""), 5000);
        } catch (error) {
            setCheckStatus("Failed to start checks.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-white tracking-tight">System Overview</h2>
                    <p className="text-neutral-400 text-sm mt-1">Real-time status of domain accessibility</p>
                </div>
                <div className="flex flex-col items-end gap-2">
                    <button
                        onClick={triggerChecks}
                        disabled={loading}
                        className="bg-emerald-500 hover:bg-emerald-600 text-neutral-950 font-bold py-2 px-6 rounded-xl flex items-center transition-all shadow-[0_0_20px_rgba(16,185,129,0.2)] hover:shadow-[0_0_25px_rgba(16,185,129,0.4)] disabled:opacity-50"
                    >
                        <RefreshCw className={`w-4 h-4 mr-2 ${loading && "animate-spin"}`} />
                        {loading ? "Triggering..." : "Run Checks Now"}
                    </button>
                    {checkStatus && <span className="text-emerald-400 text-xs font-medium animate-pulse">{checkStatus}</span>}
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard title="Total Domains" value={stats.totalDomains.toString()} icon={Globe} color="blue" trend="+12 this week" />
                <StatCard title="Domains Checked" value={stats.checkedToday.toString()} icon={Activity} color="emerald" trend="Last 24 hours" />
                <StatCard title="Currently Blocked" value={stats.currentlyBlocked.toString()} icon={AlertTriangle} color="red" trend="Requires attention" />
            </div>

            <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">Provider Status</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {providers.map((provider) => (
                        <div key={provider.name} className="glass border border-neutral-800 p-4 rounded-xl flex items-center justify-between">
                            <span className="text-sm font-medium text-neutral-300">{provider.name}</span>
                            <div className={`flex items-center text-xs font-semibold px-2 py-1 rounded border ${provider.status === "RUNNING" ? "text-emerald-400 bg-emerald-400/10 border-emerald-400/20" : "text-neutral-400 bg-neutral-800 border-neutral-700"}`}>
                                {provider.status === "RUNNING" && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-2 animate-pulse"></span>}
                                {provider.status}
                            </div>
                        </div>
                    ))}
                    {providers.length === 0 && <div className="text-neutral-500 text-sm col-span-4">No providers configured</div>}
                </div>
            </div>

            <div className="space-y-4">
                <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold text-white">Domain Status</h3>
                    <button className="text-sm text-emerald-400 hover:text-emerald-300 font-medium">View All Domains &rarr;</button>
                </div>
                <div className="glass-card overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm text-neutral-400 whitespace-nowrap">
                            <thead className="bg-neutral-900/50 border-b border-neutral-800 text-xs font-semibold text-white">
                                <tr>
                                    <th className="px-4 py-4 text-center border-r border-neutral-800/50">#</th>
                                    <th className="px-6 py-4 border-r border-neutral-800/50">Domain Name</th>
                                    {providers.map(p => (
                                        <th key={p.name} className="px-4 py-4 text-center border-r border-neutral-800/50">{p.name}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-neutral-800/50">
                                {domainsData.length === 0 ? (
                                    <tr>
                                        <td colSpan={providers.length + 2} className="px-6 py-8 text-center text-neutral-500">No domains added yet</td>
                                    </tr>
                                ) : (
                                    domainsData.map((d, index) => (
                                        <tr key={d.id} className="hover:bg-neutral-900/30 transition-colors">
                                            <td className="px-4 py-3 text-center border-r border-neutral-800/50">{index + 1}</td>
                                            <td className="px-6 py-3 font-medium text-blue-400 border-r border-neutral-800/50">{d.domain}</td>
                                            {providers.map(p => {
                                                const check = d.checks?.find((c: any) => c.provider_key === p.name);
                                                let statusColor = "text-neutral-500 bg-neutral-800/50 border-neutral-700/50";
                                                let statusText = "OFF";

                                                if (check) {
                                                    if (check.status === "AMAN") {
                                                        statusColor = "text-emerald-400 bg-emerald-400/10 border-emerald-400/20";
                                                        statusText = "AMAN";
                                                    } else if (check.status === "BLOCKIR") {
                                                        statusColor = "text-rose-400 bg-rose-500/10 border-rose-500/20";
                                                        statusText = "BLOCKIR";
                                                    } else if (check.status === "TIMEOUT" || check.status === "REDIRECT") {
                                                        statusColor = "text-amber-400 bg-amber-500/10 border-amber-500/20";
                                                        statusText = check.status;
                                                    }
                                                }

                                                return (
                                                    <td key={`${d.id}-${p.name}`} className="px-4 py-3 text-center border-r border-neutral-800/50">
                                                        <span className={`inline-flex items-center text-xs font-semibold px-2.5 py-1 rounded border ${statusColor}`}>
                                                            {statusText}
                                                        </span>
                                                    </td>
                                                );
                                            })}
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    );
}
