import { NextRequest, NextResponse } from "next/server";
import { getPrisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
    try {
        const prisma = getPrisma();
        const providers = await prisma.provider.findMany({
            orderBy: { key: "asc" }
        });
        return NextResponse.json({ providers });
    } catch (error) {
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

export async function POST(req: NextRequest) {
    try {
        const session = await getSession(req);
        if (!session || session.role === "ADMIN") {
            return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
        }

        const body = await req.json();
        const { key, proxy_url } = body;

        let formattedUrl = proxy_url ? proxy_url.trim() : null;
        if (formattedUrl && !formattedUrl.startsWith("http://") && !formattedUrl.startsWith("https://") && !formattedUrl.startsWith("socks5://")) {
            formattedUrl = "http://" + formattedUrl;
        }

        if (!key) {
            return NextResponse.json({ error: "Missing provider key" }, { status: 400 });
        }

        const prisma = getPrisma();
        await prisma.provider.update({
            where: { key },
            data: { proxy_url: formattedUrl }
        });

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error("Provider update error:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}
