import { NextRequest, NextResponse } from "next/server";
import { checkerQueue } from "@/lib/queue";
import { getPrisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
    try {
        const prisma = getPrisma();

        // Find all active domains
        const domains = await prisma.domain.findMany({
            where: { is_active: true }
        });

        if (domains.length === 0) {
            return NextResponse.json({ message: "No active domains to check" }, { status: 200 });
        }

        // Add a master "check-all" job to the queue
        // The worker will break this down into individual provider jobs
        await checkerQueue.add(
            "dispatch-all",
            { isManual: true, timestamp: Date.now() },
            {
                removeOnComplete: true,
                removeOnFail: true,
            }
        );

        return NextResponse.json({ success: true, message: `Triggered checks for ${domains.length} domains in background` });
    } catch (error: any) {
        console.error("Failed to trigger checks:", error);
        return NextResponse.json({ error: "Failed to trigger checks", details: error.message }, { status: 500 });
    }
}
